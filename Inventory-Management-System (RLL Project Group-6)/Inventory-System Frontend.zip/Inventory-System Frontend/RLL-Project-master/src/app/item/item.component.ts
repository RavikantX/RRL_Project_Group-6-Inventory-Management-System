import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  alertbar()
  {
    alert('Item Added Sucessfully !!')
    // this.snackbar.open('Item Succefully','close')
  }
}
