export class Customer {
    fullName:String;
	phoneNumber:String;
	 phone2:String;
     email:String
     customerId:String;
	 address:String;
     address2:String;
     status:String;
     city:String;
     district:String;
}
