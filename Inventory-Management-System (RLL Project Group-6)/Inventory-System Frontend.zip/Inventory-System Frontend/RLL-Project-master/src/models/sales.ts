
export class Sales{
item_name:String;
item_number:String;
quantity:String;
customer_name:String;
customer_id:String;
unity_price:String;
total_stock:String;
sale_id:String;
discount:String;
sale_date:String;

}